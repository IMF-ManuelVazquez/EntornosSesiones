package bancoED;

public class Main {

	public static void main(String[] args) {
		
		// Creamos dos cuentas: cuenta 1 y cuenta 2 con 5000 y 10000 euros de cuant�a respectivamente.
		CuentaBancaria cuenta1 = new CuentaBancaria("ES6621000418401234567891", "Pepe", "26921373B", 5000);
		CuentaBancaria cuenta2 = new CuentaBancaria("ES6621000418401234567891", "Pepe", "26921373B", 10000);
		
		// Resetear cuenta1
		cuenta1 = new CuentaBancaria("ES6621000418401234567891", "Pepe", "26921373B", 5000);
		
		// Ingresamos en la cuenta 1 1000 euros.
		cuenta1.ingresarEnCuenta(1000);
		
		// Retiramos en la cuenta 1 500 euros.
		cuenta1.retirarDeCuenta(500);
		
		// Mostramos cuent�a de la cuenta1
		double cuentiaEnCuenta = cuenta1.getCuantia();
		System.out.println("cuantiaEnCuenta: "+cuentiaEnCuenta);
		
		// Realizar transferencia de cuenta 1 a cuenta 2 aplicando comisiones.
		cuenta1.realizarTransferenciaConComision(cuenta2, 100);  // A uno se le resta y al otro se le suma, pero no se le suema integramente sino que se le retira la comision del banco.
		//System.out.println(cuenta1.getCuantia());
		//System.out.println(cuenta2.getCuantia());
		
		// Realizar transferencia de cuenta 1 a cuenta 2 sin aplicar comisiones.
		cuenta1.realizarTransferenciaSinComision(cuenta2, 100);
		//System.out.println(cuenta1.getCuantia());
		//System.out.println(cuenta2.getCuantia());
		
		// Realizar transferencia de cuenta 1 a cuenta 2 aplicando comisiones y un delay de 5 segundos.
		cuenta1.realizarTransferenciaTras5Segundos(cuenta2, 100);
		//System.out.println(cuenta1.getCuantia());
		//System.out.println(cuenta2.getCuantia());
		
		System.out.println("FIN");
		
	}

}
