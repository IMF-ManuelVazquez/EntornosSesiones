package bancoED;

public class CuentaBancaria {
	
	private final double COMISION_BANCARIA = 0.02;
	private String iBAN;
	private String nombre;
	private String dNI;
	private double cuantia;
	
	public CuentaBancaria(String iBAN, String nombre, String dNI, double cuantia) {
		super();
		this.iBAN = iBAN;
		this.nombre = nombre;
		this.dNI = dNI;
		this.cuantia = cuantia;
	}

	
	public void ingresarEnCuenta(double ingreso) {
		System.out.println("Ingreso en la cuenta "+this.iBAN+" realizado.");
		this.cuantia = this.cuantia + ingreso;
	}
	
	public void retirarDeCuenta(double retirada) {
		System.out.println("Retirada de la cuenta "+this.iBAN+" realizado.");
		this.cuantia = this.cuantia - retirada;
	}
	
	
	private void transferir (CuentaBancaria cuentadestino, int ingreso, double comision) {
		System.out.println("Iniciando transferencia de:"+this.iBAN+" hacia "+cuentadestino.getiBAN()+ "con comision del "+comision);
		this.retirarDeCuenta(ingreso);
		double ingreso_real = ingreso - (ingreso*comision);
		cuentadestino.ingresarEnCuenta(ingreso_real);
	}
	
	public void realizarTransferenciaConComision(CuentaBancaria cuentadestino, int ingreso) {
		transferir(cuentadestino,ingreso,COMISION_BANCARIA);
	}
	
	
	public void realizarTransferenciaSinComision(CuentaBancaria cuentadestino, int ingreso) {
		transferir(cuentadestino,ingreso,0);
	}
	
	
	public void realizarTransferenciaTras5Segundos (CuentaBancaria cuentadestino, int ingreso) {
		realizarTransferenciaConDelay(cuentadestino, ingreso, 5000);
	}
	
	public void realizarTransferenciaConDelay (CuentaBancaria cuentadestino, int ingreso, int delay) {
		System.out.println("Esperamos: "+delay+" ms");
		try {
			Thread.sleep(delay);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Iniciando transferencia de:"+this.iBAN+" hacia "+cuentadestino.getiBAN());
		transferir(cuentadestino,ingreso,COMISION_BANCARIA);
	}
	
	
	public String getiBAN() {
		return iBAN;
	}

	public void setiBAN(String iBAN) {
		this.iBAN = iBAN;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getdNI() {
		return dNI;
	}

	public void setdNI(String dNI) {
		this.dNI = dNI;
	}

	public double getCuantia() {
		return cuantia;
	}

	public void setCuantia(double cuantia) {
		this.cuantia = cuantia;
	}
	
}
